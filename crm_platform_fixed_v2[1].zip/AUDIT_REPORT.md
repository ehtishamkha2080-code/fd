# CRM Platform — Audit & Fix Report (v2)

Date: 2026-07-02 · Scope: full codebase (Laravel 11, PHP 8.2+, MySQL, Railway)

## Scores
| Area | Score |
|---|---|
| Overall Health | 88/100 |
| Security | 90 |
| Performance | 85 |
| Code Quality | 88 |
| Scalability | 82 |
| Maintainability | 88 |
| SEO | n/a (internal auth-only app; robots.txt present) |

Syntax: 0 errors across all PHP files (php -l). All fixes applied in place.

## Bugs Found & Fixed

### Critical
1. **IDOR — Inbox** (`InboxController`): any authenticated user could open, message, re-assign, or change status of ANY conversation by guessing IDs. Index scoped agent visibility, but show/sendMessage/sendTemplate/addNote/updateStatus/call did not.
   **Fix:** `authorizeConversation()` enforced on every conversation-scoped action; inbox routes now behind `permission:inbox.view`; assign restricted — `inbox.assign` holders reassign freely, agents may only claim unassigned conversations for themselves (route + controller + UI "Claim" button).
2. **Unauthenticated Twilio webhooks** (`VoiceWebhookController`): `/api/webhooks/voice/*` accepted any request — attacker could enumerate `?user_id=` to harvest agent phone numbers from returned TwiML, or forge call statuses.
   **Fix:** `X-Twilio-Signature` HMAC-SHA1 validation (fails closed if token missing) on both endpoints.
3. **WhatsApp signature bypass**: with `WHATSAPP_APP_SECRET` unset, `hash_hmac` ran with an empty key — forgeable signatures accepted.
   **Fix:** fail closed on empty secret.
4. **No trusted proxies**: behind Railway's TLS-terminating proxy, `$request->secure()` was always false → HSTS never sent, secure-cookie logic wrong, and Twilio URL signature validation impossible.
   **Fix:** `trustProxies(at: '*')` in `bootstrap/app.php`.
5. **No login rate limiting** — credential brute-force possible. **Fix:** `throttle:5,1` on POST /login.

### High
6. **Webhook retry storm** (`WhatsAppWebhookHandler`): Meta retries deliveries; the unique index on `wa_message_id` made duplicates throw → 500 → more retries. **Fix:** idempotency check before insert.
7. **Synchronous Claude API call inside the Meta webhook**: multi-second AI reply generation ran inline; Meta times out and retries → duplicate auto-replies. **Fix:** new queued job `App\Jobs\SendAiAutoReply` (re-checks agent assignment at execution time); webhook now returns immediately.
8. **Status enum crash**: Meta statuses outside `sent/delivered/read/failed` (e.g. `deleted`) threw on the enum column → webhook 500 loop. **Fix:** whitelist.
9. **DB password on process list**: `mysqldump -p<password>` exposed the password via `ps`. **Fix:** `MYSQL_PWD` env var; also added `--single-transaction --quick`, port flag, 600s timeout.
10. **Admin lockout** (`UserManagementController`): admin could demote self or the last active admin. **Fix:** guards on both `updateRole` and `toggleActive`; password rule upgraded to `Password::min(8)->letters()->numbers()`.

### Medium
11. **Duplicate conversation threads**: `firstOrCreate` keyed on `status='open'` spawned a second thread whenever one sat in `pending`. **Fix:** reuse any open/pending conversation.
12. **Report off-by-one-day**: `to` compared as midnight → all records after 00:00 on the final day excluded; from/to also unvalidated. **Fix:** date validation + `endOfDay()` across index/PDF/Excel/avg-response-time.
13. **Appointments UI dead-end**: store/status routes and permissions existed, but the page had no create form or status control. **Fix:** create form + inline status dropdown, gated by `leads.manage`.
14. **Deprecated `X-XSS-Protection: 1; mode=block`** (reintroduces vulnerabilities in legacy browsers): set to `0` per OWASP; added `Permissions-Policy`.
15. **Missing indexes** on every hot path (inbox sort, thread load, report ranges, appointments, audit trail). **Fix:** migration `0005_..._add_performance_indexes.php`.
16. **No automatic migrations on deploy**: added `php artisan migrate --force` to Railway entrypoint (web service only, guarded so worker/scheduler don't race).

### Low / cleanup
17. Removed now-dead `AiAssistantService` / `WhatsAppCloudApiService` dependencies from the webhook handler (moved into the job).
18. Assign panel hidden in UI for users without `inbox.assign` (server already enforces).
19. `.env.example`: Railway variable-reference mapping documented (`${{MySQL.MYSQLHOST}}` etc).

## Modified Files
```
routes/web.php                                    bootstrap/app.php
app/Http/Controllers/InboxController.php          app/Http/Controllers/ReportController.php
app/Http/Controllers/UserManagementController.php app/Http/Controllers/AppointmentController.php
app/Http/Controllers/Api/VoiceWebhookController.php
app/Http/Middleware/SecurityHeaders.php
app/Services/Voice/VoiceCallService.php           app/Services/WhatsApp/WhatsAppCloudApiService.php
app/Services/WhatsApp/WhatsAppWebhookHandler.php  app/Console/Commands/RunBackupCommand.php
app/Jobs/SendAiAutoReply.php                      (new)
database/migrations/0005_01_01_000000_add_performance_indexes.php (new)
resources/views/inbox/show.blade.php              resources/views/crm/appointments.blade.php
deploy/railway/entrypoint.sh                      .env.example
AUDIT_REPORT.md                                   (new)
```

## Railway Deployment (unchanged 3-service model, see deploy/railway/README.md)
1. Push repo to GitHub → Railway "New Project" → Deploy from repo (Dockerfile auto-detected).
2. Add MySQL plugin; set variables per `.env.example` (use `${{MySQL.*}}` references).
3. Generate `APP_KEY` locally: `php artisan key:generate --show` → paste into variables.
4. Add 2 more services from the same repo:
   - worker: `php artisan queue:work --tries=3 --sleep=3` ← **now required** (AI auto-replies are queued)
   - scheduler: `php artisan schedule:work`
5. Migrations run automatically on web boot; seed once via one-off shell: `php artisan db:seed --force`.
6. Point Meta webhook to `https://<domain>/api/webhooks/whatsapp`, Twilio TwiML/status URLs per `.env.example`.
7. Health check: `/up` (pre-wired).

## Production Checklist
- [ ] Change seeded admin password (`admin@example.com` / `ChangeMe123!`) immediately
- [ ] Set `WHATSAPP_APP_SECRET` + `WHATSAPP_VERIFY_TOKEN` (webhooks now hard-fail without them — intentional)
- [ ] Set `TWILIO_AUTH_TOKEN` before enabling voice (webhooks reject unsigned requests)
- [ ] `FILESYSTEMS_BACKUP_DISK` → S3/Backblaze (Railway disk is ephemeral; local backups vanish on redeploy)
- [ ] Commit a `composer.lock` (repo ships without one → non-reproducible builds)
- [ ] `AI_AUTO_REPLY_ENABLED=true` only after knowledge-base articles are published

## Remaining Risks (accepted / roadmap)
- **Tailwind via CDN** in layouts: fine for internal tool, but adds a third-party runtime dependency; build a compiled CSS bundle when convenient.
- `averageResponseTimeMinutes` uses MySQL `TIMESTAMPDIFF` — intentional (MySQL is the target DB) but blocks SQLite-based tests.
- `AiAssistantService::suggestReply()` currently has no UI/route consuming it — retained as the intended "suggested reply" feature hook.
- WorkflowEngine condition matching uses loose `!=` (intentional for numeric-string configs); document when building the workflow admin UI.
- No test suite yet (`tests/` empty) — see roadmap.
- No CSP header: Blade views use inline scripts + CDN Tailwind; adopt CSP after asset pipeline is built.

## 30/60/90 Roadmap
- **30d:** commit composer.lock; feature tests for auth, RBAC, inbox authorization, webhook idempotency; move report exports to queued jobs for large ranges; S3 backups.
- **60d:** compiled asset pipeline (Vite) + CSP; workflow admin UI; template variable filling for sendTemplate; WhatsApp media download/storage (media IDs currently stored, not fetched).
- **90d:** horizontal scaling review (Redis cache/queue instead of database driver), read-model dashboards, GHL/ERP sync scheduling + reconciliation jobs, load testing.
