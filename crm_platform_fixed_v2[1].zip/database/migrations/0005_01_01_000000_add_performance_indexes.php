<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Hot-path indexes. Foreign keys already carry indexes in MySQL, but the
 * columns below are sorted/filtered on directly and were previously full scans:
 *   - inbox list: conversations ordered by last_message_at, filtered by status
 *   - conversation thread: messages by (conversation_id, created_at)
 *   - reports: messages/leads/conversations filtered by created_at + direction
 *   - appointments list: ordered by scheduled_at
 *   - audit trail: filtered by action / created_at
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('conversations', function (Blueprint $table) {
            $table->index('last_message_at');
            $table->index(['status', 'last_message_at']);
        });

        Schema::table('messages', function (Blueprint $table) {
            $table->index(['conversation_id', 'created_at']);
            $table->index(['direction', 'created_at']);
        });

        Schema::table('leads', function (Blueprint $table) {
            $table->index('created_at');
        });

        Schema::table('appointments', function (Blueprint $table) {
            $table->index('scheduled_at');
        });

        Schema::table('audit_logs', function (Blueprint $table) {
            $table->index('action');
            $table->index('created_at');
        });
    }

    public function down(): void
    {
        Schema::table('conversations', function (Blueprint $table) {
            $table->dropIndex(['last_message_at']);
            $table->dropIndex(['status', 'last_message_at']);
        });

        Schema::table('messages', function (Blueprint $table) {
            $table->dropIndex(['conversation_id', 'created_at']);
            $table->dropIndex(['direction', 'created_at']);
        });

        Schema::table('leads', function (Blueprint $table) {
            $table->dropIndex(['created_at']);
        });

        Schema::table('appointments', function (Blueprint $table) {
            $table->dropIndex(['scheduled_at']);
        });

        Schema::table('audit_logs', function (Blueprint $table) {
            $table->dropIndex(['action']);
            $table->dropIndex(['created_at']);
        });
    }
};
