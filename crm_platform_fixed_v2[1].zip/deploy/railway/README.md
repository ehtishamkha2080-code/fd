# Deploying on Railway — What's Different From a Normal VPS

Railway builds your `Dockerfile` directly and runs **one process per service**, listening
on whatever port it assigns via the `$PORT` environment variable. It does **not** read
`docker-compose.yml` — that file is only for self-hosted Docker (your own VPS).

This Dockerfile was rewritten specifically to work with that model: nginx + php-fpm now
run together inside a single container via supervisor, and the nginx config is generated
at startup using Railway's injected `$PORT` (which can change between deploys).

## You need 3 separate Railway services, all from the same GitHub repo

| Service | Start Command | Purpose |
|---|---|---|
| **web** | *(leave default — uses the Dockerfile's CMD)* | Serves the actual website/API |
| **worker** | `php artisan queue:work --tries=3 --sleep=3` | Sends WhatsApp messages, runs AI calls, processes anything queued |
| **scheduler** | `php artisan schedule:work` | Runs the nightly backup (replaces cron, which Railway doesn't give you direct access to) |

### How to add the worker and scheduler services
1. In your Railway project, click "+ New" → "GitHub Repo" → select the **same repo** again.
2. This creates a second service. Go to its Settings → Deploy → "Custom Start Command"
   and enter `php artisan queue:work --tries=3 --sleep=3`.
3. Repeat once more for the scheduler with `php artisan schedule:work`.
4. Each of these 3 services needs the **same environment variables** (DB connection, API
   keys, etc) — Railway lets you copy variables between services, or use a shared
   "Variable Group" so you only set them once.

Without the worker service, outbound WhatsApp messages and AI replies will sit in the
`jobs` table forever and never actually send — this is a real functional gap, not
optional polish, if your code uses queued jobs.

## A note on persistence

Railway's filesystem is ephemeral — anything written to `storage/` (logs, local backup
files) is lost on every redeploy. This is fine for logs/cache (already configured to use
the database, not files, in `.env.example`), but it means:
- The nightly `backup:run` command will create a `.sql` file that disappears on next
  deploy unless you change `FILESYSTEMS_BACKUP_DISK` to point at real cloud storage
  (S3, Backblaze, etc) instead of `local`. For a first test deployment this is fine to
  leave as-is; revisit before this becomes the client's production system.

## Health checks

Railway periodically hits your service to confirm it's alive. This project's nginx config
routes `/up` straight to Laravel's built-in health check route (already wired in
`bootstrap/app.php` via `health: '/up'`), so no extra setup is needed — Railway should
detect the service as healthy automatically once env vars and the database are connected.
