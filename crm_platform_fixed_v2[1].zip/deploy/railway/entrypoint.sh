#!/usr/bin/env bash
set -e

# Railway runs this same image for multiple services (web, queue worker,
# scheduler) with different start commands. Only set up nginx when this
# container is actually serving HTTP (i.e. the default supervisord CMD).
if [[ "$1" == "supervisord" ]]; then
    : "${PORT:=8080}"
    export PORT

    envsubst '${PORT}' < /etc/nginx/templates/default.conf.template > /etc/nginx/conf.d/default.conf

    nginx -t
fi

# Cache config/routes/views for production performance — safe to run on every
# boot since these commands are idempotent. Skipped if APP_KEY isn't set yet
# (first deploy, before `php artisan key:generate` has run).
if [ -n "$APP_KEY" ]; then
    # Automatic migrations (web service only — worker/scheduler pass their own CMD
    # and skip this block's supervisord branch, but they still hit this section, so
    # guard on the CMD to avoid three containers racing to migrate at once).
    if [[ "$1" == "supervisord" ]]; then
        php artisan migrate --force || true
    fi

    php artisan config:cache || true
    php artisan route:cache || true
    php artisan view:cache || true
    # Create the public/storage symlink so uploaded files are web-accessible
    php artisan storage:link --force || true
fi

exec "$@"
