# WhatsApp CRM Platform — Full Project Code (All 5 Milestones)

Hand-written Laravel 11 application code covering the full commercial scope. Composer
packages must be installed on your own machine/server (this sandbox can't reach
packagist.org), so treat this as a complete, structured codebase to drop into a fresh
Laravel install, not a pre-built running app.

## Setup

1. `composer create-project laravel/laravel crm-platform` (Laravel 11)
2. Copy this package's `app/`, `database/`, `resources/`, `routes/`, `config/` contents
   into the new project, merging folders.
3. Required composer packages beyond the default Laravel install:
   ```
   composer require barryvdh/laravel-dompdf maatwebsite/excel guzzlehttp/guzzle
   ```
4. Merge `config/services_additions.php` into your `config/services.php`.
5. Append the contents of `.env.additions.example` into your real `.env` and fill in
   actual credentials (WhatsApp, Anthropic, GHL, ERP, Twilio — see notes below).
6. Register middleware per `MIDDLEWARE_REGISTRATION.php`.
7. Register `app/Console/Commands/RunBackupCommand.php` if not auto-discovered, and
   schedule it as shown in that same file.
8. `php artisan migrate && php artisan db:seed --class=RbacSeeder`
9. Log in at `/login` with `admin@example.com` / `ChangeMe123!` — change immediately.

## Module map

| Milestone | Folder/files |
|---|---|
| M1 Foundation & RBAC | `app/Models/{User,Role,Permission}.php`, `app/Http/Middleware/EnsureUserHas*`, `app/Http/Controllers/{DashboardController,UserManagementController}.php` |
| M2 WhatsApp / Inbox | `app/Services/WhatsApp/*`, `app/Http/Controllers/{InboxController,Api/WhatsAppWebhookController}.php`, `resources/views/inbox/*` |
| M3 CRM/Automation/AI | `app/Models/{Lead,LeadStage,Workflow*,KnowledgeBaseArticle,Appointment}.php`, `app/Services/{AI,Automation,Integrations}/*`, `app/Http/Controllers/{LeadController,AppointmentController}.php` |
| M4 Voice/Reports/Security | `app/Services/Voice/VoiceCallService.php`, `app/Http/Controllers/ReportController.php`, `app/Exports/LeadsExport.php`, `app/Http/Middleware/SecurityHeaders.php`, `app/Console/Commands/RunBackupCommand.php` |
| M5 Deployment | See "Deployment checklist" below |

## Deploying on Railway

See [`deploy/railway/README.md`](deploy/railway/README.md) — Railway needs a different
container setup than a self-hosted VPS (single container serving HTTP on a dynamic port,
no `docker-compose.yml`, no cron access), and the Dockerfile in this repo is built
specifically to handle that.

## Bugs found and fixed in this pass

I reviewed the codebase end-to-end against Laravel 11 conventions and fixed these real
issues (none were caught by execution, since this sandbox has no PHP — they're fixed
based on careful manual review against Laravel 11's actual API surface):

0. **Railway incompatibility (critical)**: the original `Dockerfile` only ran `php-fpm`
   on port 9000 — an internal protocol, not HTTP — and relied on a separate `nginx`
   container from `docker-compose.yml`, which Railway never reads. Deployed as-is, the
   site would never respond to any HTTP request. Rewrote the Dockerfile as a single
   container running nginx + php-fpm via supervisor, with nginx's port substituted at
   startup from Railway's `$PORT` variable. See `deploy/railway/`.

1. **Fatal boot error**: `bootstrap/app.php` called `->withSchedule()`, which is not a
   real method on Laravel 11's `Application::configure()` builder. This would have
   thrown a fatal error on every single request. Fixed by moving the backup schedule
   into `routes/console.php` using the `Schedule` facade — the correct Laravel 11 pattern.
2. **Missing queue/cache tables**: `.env.example` sets `QUEUE_CONNECTION=database` and
   `CACHE_STORE=database`, and `docker-compose.yml` runs a queue worker — but no
   migration created the `jobs`, `cache`, `cache_locks`, `job_batches`, or `failed_jobs`
   tables. Added `0000_01_01_000000_create_cache_and_queue_tables.php`.
3. **Missing service provider registration**: Laravel 11 requires `bootstrap/providers.php`
   to boot at all. It didn't exist. Added it along with a basic `AppServiceProvider`.
4. **Docker networking bug**: `.env.example` had `DB_HOST=127.0.0.1`, which inside Docker's
   network resolves to the app container itself, not the `db` container — this would
   make the Docker deployment path fail to connect to MySQL. Fixed with `DB_HOST=db`
   and an inline comment explaining the Docker-vs-bare-metal difference.
5. **Code cleanliness**: removed a redundant fully-qualified class reference in
   `RunBackupCommand` and stale comments pointing at `app/Console/Kernel.php`, which
   doesn't exist in Laravel 11's slimmed-down skeleton.
6. **Missing explicit dependency**: added `symfony/process` to `composer.json` since
   `RunBackupCommand` uses it directly.
7. **Docker build failure on Railway (critical)**: `Dockerfile`'s `composer install` step
   used a `--no-blocking` flag, which does not exist as a Composer option. This made the
   Docker build fail immediately during `composer install`, so the image never finished
   building — this was the actual cause of the Railway deploy error. Removed the invalid
   flag. Verified locally with Composer 2.7.1: the install command now parses correctly
   and proceeds to dependency resolution (confirmed with `composer validate` and by
   reproducing the exact failure before the fix and confirming it's gone after).

## QA pass (post-deploy-fix) — deeper review

After the Railway fix above, I ran a full second pass: linted every `.php` and
`.blade.php` file, cross-checked every model's `$fillable`/casts/relations against its
migration's actual columns, verified every `route()` name used in a view or redirect
against `routes/web.php`, verified every `config()` key referenced in code exists in the
matching config file, and traced each service class to confirm something actually calls
it. Two real bugs and one real UX gap turned up:

8. **Security bug — deactivating a user didn't revoke an active session.** `is_active`
   was only checked at login (`AuthenticatedSessionController`) and inside the `role:`
   middleware (admin-only routes). Dashboard, Inbox, CRM, and Reports either have no
   role/permission gate or only the `permission:` gate, which never checked `is_active`.
   So toggling a user inactive while they were already logged in didn't actually cut
   their access — they kept working until they happened to log out. Fixed by adding
   `App\Http\Middleware\EnsureUserIsActive` (alias `active`) and applying it to the
   entire authenticated route group in `routes/web.php`, so a deactivated user is logged
   out and blocked on their very next request, not just their next login attempt.
9. **Dead config — `FILESYSTEMS_BACKUP_DISK` had no effect.** `.env.example` and the
   Railway README both tell you to set `FILESYSTEMS_BACKUP_DISK` to point nightly
   backups at S3 instead of the ephemeral local disk, but `config/filesystems.php` never
   defined a `backup_disk` key — `RunBackupCommand`'s `config('filesystems.backup_disk')`
   call always silently fell back to `'local'` no matter what the env var said. This
   meant following the documented "revisit before production" instruction wouldn't have
   actually worked. Added the missing `'backup_disk' => env('FILESYSTEMS_BACKUP_DISK', 'local')`
   entry to `config/filesystems.php`.
10. **UX gap — no way to navigate the app.** The main nav (`layouts/app.blade.php`) only
    ever showed "Manage Users" (admin-only) and "Logout" — no links to Dashboard, Inbox,
    Pipeline, Appointments, or Reports for anyone. Every other page was only reachable by
    typing the URL directly. Added nav links, gated by the same permissions the routes
    themselves use (`leads.view` for Pipeline/Appointments, `reports.view` for Reports),
    so agents/managers/admins each see only what they can actually access.

### Voice calling — now wired end-to-end

Previously `VoiceCallService` existed but nothing called it — no "Call" button, no
webhook route. Built out the full flow:

- **Click-to-call**: a "📞 Call" button on the conversation view (`inbox/show.blade.php`)
  posts to `inbox.call` → `InboxController::call()` → `VoiceCallService::initiateCall()`,
  which tells Twilio to dial the contact.
- **Bridging**: added `Api\VoiceWebhookController::twiml()`, registered at
  `/api/webhooks/voice/twiml` (matches `TWILIO_TWIML_URL` in `.env.example`, which was
  already pointing here — it just had nothing behind it before). When the contact
  answers, Twilio fetches this and gets a `<Dial>` back that bridges the call to the
  agent's phone number.
- **Call status**: added `Api\VoiceWebhookController::status()` at
  `/api/webhooks/voice/status` (matches `TWILIO_STATUS_CALLBACK_URL`), which calls the
  existing `logCallCompletion()` to update the call's duration/status/recording.
- **Call history**: added `Contact::voiceCalls()` and a call-history panel in the
  conversation sidebar.
- **Agent phone numbers**: added an optional "Phone" field to the admin "Add New User"
  form (`UserManagementController::store`), since the bridge step needs somewhere to
  dial — without a phone number on the agent's account there was no way to complete a
  call regardless of how the webhook was wired.
- Fixed a stale docblock in `VoiceCallService` that referenced a `logIncomingCall()`
  method that was never actually written (the real method is `logCallCompletion()`).

This covers outbound click-to-call only — inbound calls (someone calling your Twilio
number directly) aren't handled, since that wasn't part of the original spec or the
existing `VoiceCall` model's assumptions. Add an inbound-call webhook route the same
way if that's needed later.

## Things that genuinely need your input before going live

These aren't bugs — they're decisions only the client/you can make, flagged inline in
the code with comments:

- **ERP system**: the spec says "ERP integration" without naming which ERP. `ErpIntegrationService`
  is a generic REST adapter — confirm the actual system (SAP, Odoo, NetSuite, custom) and
  adjust endpoint paths to match its real API docs.
- **GHL auth version**: GoHighLevel has v1 (API key) and v2 (OAuth) APIs with different
  request shapes. `GoHighLevelService` targets v2 — confirm which the client's GHL account uses.
- **Voice provider**: not specified in the contract; `VoiceCallService` targets Twilio's
  REST pattern as the most common choice. Swap if the client uses a different provider.
- **WhatsApp Business verification**: Meta requires business verification and template
  approval before sending template messages or messaging users who haven't messaged you
  first in the last 24h — this is a Meta-side process, not something code can bypass.
- **AI auto-reply**: defaults to OFF (`AI_AUTO_REPLY_ENABLED=false`) so a human always
  triages first conversations until you and the client are confident in its accuracy.
  Turn on per the client's comfort level.

## Deployment (two supported paths)

This package now includes everything needed to actually deploy — not just app code.

### Path A: Docker (recommended)
1. Copy `.env.example` to `.env`, fill in real credentials.
2. `docker compose build`
3. `docker compose up -d`
4. `docker compose exec app php artisan key:generate`
5. `docker compose exec app php artisan migrate --seed`
6. Point your domain's DNS at the server, put real SSL certs in `deploy/ssl/`
   (referenced by `deploy/nginx.conf`), restart the `nginx` container.

### Path B: Bare metal / VPS (no Docker)
1. `composer create-project laravel/laravel crm-platform` then merge this package's
   files in, OR clone this code directly if it's already a git repo with `composer.json`
   at the root (it is, in this package).
2. Copy `.env.example` to `.env`, fill in real credentials.
3. Run `./deploy/deploy.sh` — it installs dependencies, generates the app key,
   runs migrations, and caches config/routes/views in one pass.
4. Install the queue worker via `deploy/supervisor-queue.conf`
   (`supervisorctl reread && supervisorctl update && supervisorctl start crm-queue:*`).
5. Add the cron line from `deploy/crontab.txt` so `php artisan schedule:run`
   (which triggers the nightly backup) actually fires.
6. Point Nginx at `deploy/nginx.conf` (adjust paths/domain), with PHP-FPM running
   on the same host instead of a separate `app` container.

### After either path — always required
- Set the WhatsApp webhook URL in Meta's App Dashboard to
  `https://yourdomain.com/api/webhooks/whatsapp`, using your `WHATSAPP_VERIFY_TOKEN`
  for the handshake.
- Log in with the seeded admin (`admin@example.com` / `ChangeMe123!`) and change
  the password immediately — `/admin/users` lets you create real accounts after.
- Run a real send/receive test with WhatsApp before considering Milestone 2 "live."

## Deployment checklist (Milestone 5, expanded)


- Set `APP_ENV=production`, `APP_DEBUG=false`
- Run `php artisan config:cache route:cache view:cache`
- Set up HTTPS (required by Meta for the WhatsApp webhook URL)
- Point the WhatsApp webhook URL at `https://yourdomain.com/api/webhooks/whatsapp`
  in Meta's App Dashboard, using `WHATSAPP_VERIFY_TOKEN` for the handshake
- Schedule `backup:run` and a queue worker (`php artisan queue:work`) via Supervisor/systemd
- Hand over `.env` credentials securely (not via plain chat/email)

## Honesty note

This pass had PHP 8.3 and Composer 2.7.1 available (no packagist.org access, so a full
`vendor/` install and artisan boot still weren't possible). What was actually verified
this time:
- `php -l` on every `.php` file in the project — zero syntax errors.
- `composer validate` — `composer.json` is valid.
- Reproduced the exact `composer install` command from the Dockerfile and confirmed it
  failed on the invalid `--no-blocking` flag; confirmed the corrected command parses
  past that point (it then only fails on the sandbox's lack of packagist.org access,
  which won't be an issue on Railway's build servers).
- `composer dump-autoload -o` — no classmap/PSR-4 errors among this project's own classes.
- Cross-checked every controller referenced in `routes/web.php` / `routes/api.php` /
  `routes/console.php` against `app/Http/Controllers/` — all exist.
- `git init` + `git add -A` — confirmed `.gitignore` correctly excludes `vendor/`, `.env`,
  and runtime storage files, so nothing sensitive or bulky would get pushed to GitHub.

Still not verified (needs a real MySQL instance and installed vendor packages): a full
`php artisan migrate`, an actual Laravel boot cycle, and any live WhatsApp/Anthropic/GHL/
Twilio credentials. Budget time for a first run on Railway/staging to catch anything that
only surfaces once the framework itself is booted.

Before calling this "deployed," budget real time for:
1. A first run on a staging server (or `docker compose up` locally) to catch any
   typos or missing-import errors that are inevitable in code this size when unrun.
2. Live WhatsApp Cloud API testing — Meta requires business verification and template
   approval, which is a manual process on their side, not something this code can do.
3. The Milestone 4 UAT phase your contract already allocates for exactly this kind
   of verification.

I'm flagging this clearly rather than implying "ready for deployment" means "tested and
working" — it means the deployment *scaffolding* is complete; the verification step is
still yours to run.
