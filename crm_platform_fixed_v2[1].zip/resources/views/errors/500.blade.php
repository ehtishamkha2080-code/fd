<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>500 - Server Error</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen">
    <div class="text-center">
        <div class="text-6xl font-bold text-gray-300 mb-4">500</div>
        <h1 class="text-xl font-semibold text-gray-700 mb-2">Server Error</h1>
        <p class="text-gray-500 mb-6">Something went wrong on our end. Please try again later.</p>
        <a href="{{ url('/dashboard') }}" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 text-sm">
            Back to Dashboard
        </a>
    </div>
</body>
</html>
