@extends('layouts.app')
@section('title', 'Appointments')
@section('content')
    <h1 class="text-2xl font-semibold mb-6">Appointments</h1>

    @auth
        @if(auth()->user()->hasPermission('leads.manage'))
            <form method="POST" action="{{ route('crm.appointments.store') }}"
                  class="bg-white rounded-lg shadow-sm border p-4 mb-6 grid grid-cols-1 md:grid-cols-5 gap-3 items-end">
                @csrf
                <div>
                    <label class="block text-xs font-medium mb-1">Title</label>
                    <input type="text" name="title" required maxlength="255" class="w-full border rounded px-2 py-1.5 text-sm">
                </div>
                <div>
                    <label class="block text-xs font-medium mb-1">Contact</label>
                    <select name="contact_id" required class="w-full border rounded px-2 py-1.5 text-sm">
                        @foreach($contacts as $c)
                            <option value="{{ $c->id }}">{{ $c->name ?? $c->phone }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-medium mb-1">When</label>
                    <input type="datetime-local" name="scheduled_at" required class="w-full border rounded px-2 py-1.5 text-sm">
                </div>
                <div>
                    <label class="block text-xs font-medium mb-1">Agent</label>
                    <select name="assigned_to" class="w-full border rounded px-2 py-1.5 text-sm">
                        <option value="">—</option>
                        @foreach($agents as $agent)
                            <option value="{{ $agent->id }}">{{ $agent->name }}</option>
                        @endforeach
                    </select>
                </div>
                <button type="submit" class="bg-blue-600 text-white rounded px-4 py-1.5 text-sm font-medium hover:bg-blue-700">
                    Schedule
                </button>
            </form>
        @endif
    @endauth

    <div class="bg-white rounded-lg shadow-sm border overflow-hidden">
        <table class="w-full text-sm">
            <thead class="bg-gray-50 text-left">
                <tr><th class="px-4 py-2">Title</th><th class="px-4 py-2">Contact</th><th class="px-4 py-2">When</th><th class="px-4 py-2">Agent</th><th class="px-4 py-2">Status</th></tr>
            </thead>
            <tbody>
                @foreach($appointments as $a)
                    <tr class="border-t">
                        <td class="px-4 py-2">{{ $a->title }}</td>
                        <td class="px-4 py-2">{{ $a->contact->name ?? $a->contact->phone }}</td>
                        <td class="px-4 py-2">{{ $a->scheduled_at->format('M d, H:i') }}</td>
                        <td class="px-4 py-2">{{ $a->agent->name ?? '—' }}</td>
                        <td class="px-4 py-2">
                            @if(auth()->user()->hasPermission('leads.manage'))
                                <form method="POST" action="{{ route('crm.appointments.status', $a) }}">
                                    @csrf
                                    @method('PATCH')
                                    <select name="status" onchange="this.form.submit()" class="border rounded px-1 py-0.5 text-xs">
                                        @foreach(['scheduled','confirmed','completed','cancelled','no_show'] as $st)
                                            <option value="{{ $st }}" @selected($a->status === $st)>{{ ucfirst(str_replace('_',' ',$st)) }}</option>
                                        @endforeach
                                    </select>
                                </form>
                            @else
                                {{ ucfirst(str_replace('_',' ',$a->status)) }}
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div class="mt-4">{{ $appointments->links() }}</div>
@endsection
