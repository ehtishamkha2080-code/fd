@extends('layouts.app')
@section('title', 'Manage Users')
@section('content')
    <h1 class="text-2xl font-semibold mb-6">Manage Users</h1>

    <div class="bg-white p-6 rounded-lg shadow-sm border mb-8">
        <h2 class="font-medium mb-4">Add New User</h2>
        @if($errors->any())
            <div class="mb-4 p-3 bg-red-100 text-red-700 rounded text-sm">
                @foreach($errors->all() as $error)
                    <div>{{ $error }}</div>
                @endforeach
            </div>
        @endif
        <form method="POST" action="{{ route('admin.users.store') }}" class="grid grid-cols-1 md:grid-cols-6 gap-3">
            @csrf
            <input name="name" placeholder="Full name" required value="{{ old('name') }}"
                   class="border rounded px-3 py-2 text-sm col-span-1">
            <input name="email" type="email" placeholder="Email" required value="{{ old('email') }}"
                   class="border rounded px-3 py-2 text-sm col-span-1">
            <input name="phone" type="tel" placeholder="Phone (optional)" value="{{ old('phone') }}"
                   class="border rounded px-3 py-2 text-sm col-span-1">
            <input name="password" type="password" placeholder="Password (min 8)" required
                   class="border rounded px-3 py-2 text-sm col-span-1">
            <select name="role" required class="border rounded px-3 py-2 text-sm col-span-1">
                @foreach($roles as $role)
                    <option value="{{ $role->name }}">{{ $role->label }}</option>
                @endforeach
            </select>
            <button class="bg-blue-600 text-white rounded px-3 py-2 text-sm hover:bg-blue-700 col-span-1">
                Add User
            </button>
        </form>
    </div>

    <div class="bg-white rounded-lg shadow-sm border overflow-hidden">
        <table class="w-full text-sm">
            <thead class="bg-gray-50 text-left">
                <tr>
                    <th class="px-4 py-3">Name</th>
                    <th class="px-4 py-3">Email</th>
                    <th class="px-4 py-3">Phone</th>
                    <th class="px-4 py-3">Role</th>
                    <th class="px-4 py-3">Status</th>
                    <th class="px-4 py-3">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($users as $u)
                    <tr class="border-t hover:bg-gray-50">
                        <td class="px-4 py-3">{{ $u->name }}</td>
                        <td class="px-4 py-3">{{ $u->email }}</td>
                        <td class="px-4 py-3 text-gray-500">{{ $u->phone ?? '—' }}</td>
                        <td class="px-4 py-3">
                            <form method="POST" action="{{ route('admin.users.role', $u) }}" class="flex items-center gap-2">
                                @csrf @method('PATCH')
                                <select name="role" class="border rounded px-2 py-1 text-xs">
                                    @foreach($roles as $role)
                                        <option value="{{ $role->name }}"
                                            @selected($u->roles->pluck('name')->contains($role->name))>
                                            {{ $role->label }}
                                        </option>
                                    @endforeach
                                </select>
                                <button class="text-blue-600 text-xs hover:underline">Update</button>
                            </form>
                        </td>
                        <td class="px-4 py-3">
                            <span class="px-2 py-1 rounded text-xs {{ $u->is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' }}">
                                {{ $u->is_active ? 'Active' : 'Disabled' }}
                            </span>
                        </td>
                        <td class="px-4 py-3">
                            @if(auth()->id() !== $u->id)
                                <form method="POST" action="{{ route('admin.users.toggle', $u) }}">
                                    @csrf @method('PATCH')
                                    <button class="text-xs text-gray-600 hover:underline">
                                        {{ $u->is_active ? 'Deactivate' : 'Activate' }}
                                    </button>
                                </form>
                            @else
                                <span class="text-xs text-gray-400">Current user</span>
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="6" class="px-4 py-8 text-center text-gray-400">No users yet.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="mt-4">{{ $users->links() }}</div>
@endsection
