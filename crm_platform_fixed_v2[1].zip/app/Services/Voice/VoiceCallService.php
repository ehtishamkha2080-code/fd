<?php

namespace App\Services\Voice;

use App\Models\VoiceCall;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Voice calling integration. The spec just says "Voice integration" without
 * naming a provider — this targets the common Twilio Voice REST pattern since
 * it's the most widely used for this kind of CRM click-to-call feature.
 * If the client uses a different provider, swap the endpoint/auth below;
 * the public methods (initiateCall, logCallCompletion) and DB schema stay the same.
 *
 * Required .env values:
 *   TWILIO_ACCOUNT_SID
 *   TWILIO_AUTH_TOKEN
 *   TWILIO_FROM_NUMBER
 *   TWILIO_TWIML_URL
 *   TWILIO_STATUS_CALLBACK_URL
 *
 * Call flow (see Api\VoiceWebhookController for the other half):
 *   1. Agent clicks "Call" -> initiateCall() tells Twilio to dial the contact,
 *      with instructions to fetch TWILIO_TWIML_URL (carrying ?user_id=<agent>)
 *      once the contact answers.
 *   2. Contact answers -> Twilio fetches the TwiML URL -> VoiceWebhookController::twiml()
 *      returns <Dial> pointed at that agent's phone number, bridging the two calls.
 *   3. When the call ends -> Twilio POSTs to TWILIO_STATUS_CALLBACK_URL ->
 *      VoiceWebhookController::status() -> logCallCompletion() below.
 */
class VoiceCallService
{
    protected string $accountSid;
    protected string $authToken;
    protected string $fromNumber;

    public function __construct()
    {
        $this->accountSid = config('services.twilio.sid', '');
        $this->authToken = config('services.twilio.token', '');
        $this->fromNumber = config('services.twilio.from_number', '');
    }

    /** Used by VoiceWebhookController to set callerId on the bridged leg. */
    public function callerId(): string
    {
        return $this->fromNumber;
    }

    /**
     * Validates Twilio's X-Twilio-Signature header (HMAC-SHA1 of the full URL +
     * alphabetically-sorted POST params, keyed with the auth token). Fails closed
     * if the token is missing or the signature doesn't match — without this, the
     * webhook endpoints accept forged requests from anyone on the internet.
     * Requires trusted proxies to be configured so fullUrl() reflects the public URL.
     */
    public function validateWebhookSignature(\Illuminate\Http\Request $request): bool
    {
        if ($this->authToken === '') {
            return false;
        }

        $signature = $request->header('X-Twilio-Signature');
        if (! $signature) {
            return false;
        }

        $data = $request->fullUrl();

        if ($request->isMethod('post')) {
            $params = $request->post();
            ksort($params);
            foreach ($params as $key => $value) {
                $data .= $key.$value;
            }
        }

        $expected = base64_encode(hash_hmac('sha1', $data, $this->authToken, true));

        return hash_equals($expected, $signature);
    }

    /** Agent clicks "Call" in the CRM; this places an outbound call via the provider. */
    public function initiateCall(string $toNumber, int $userId, int $contactId): VoiceCall
    {
        // TWILIO_TWIML_URL must be set in .env — it's the public URL Twilio fetches
        // for call instructions once the contact picks up, e.g.
        // https://yourdomain.com/api/webhooks/voice/twiml. The agent's user_id is
        // appended so that endpoint knows whose phone to bridge the call to.
        $twimlUrl = config('services.twilio.twiml_url').'?'.http_build_query(['user_id' => $userId]);

        $response = Http::withBasicAuth($this->accountSid, $this->authToken)
            ->asForm()
            ->post("https://api.twilio.com/2010-04-01/Accounts/{$this->accountSid}/Calls.json", [
                'To' => $toNumber,
                'From' => $this->fromNumber,
                'Url' => $twimlUrl,
                'StatusCallback' => config('services.twilio.status_callback_url'),
                'StatusCallbackMethod' => 'POST',
            ]);

        if ($response->failed()) {
            Log::error('Twilio call initiation failed', ['body' => $response->json()]);
        }

        // Status starts as 'missed' (failed to even place) or will be updated
        // to 'completed'/'missed' via the status-callback webhook once the call ends.
        return VoiceCall::create([
            'contact_id' => $contactId,
            'user_id' => $userId,
            'direction' => 'outbound',
            'status' => $response->successful() ? 'missed' : 'failed', // 'missed' = placed, awaiting completion
            'provider_call_id' => $response->json('sid'),
            'raw_payload' => $response->json(),
        ]);
    }

    /** Called from the provider's status-callback webhook once a call ends. */
    public function logCallCompletion(array $webhookPayload): void
    {
        $call = VoiceCall::where('provider_call_id', $webhookPayload['CallSid'] ?? null)->first();

        if (! $call) {
            return;
        }

        $call->update([
            'status' => match ($webhookPayload['CallStatus'] ?? '') {
                'completed' => 'completed',
                'no-answer', 'busy' => 'missed',
                default => 'failed',
            },
            'duration_seconds' => $webhookPayload['CallDuration'] ?? null,
            'recording_url' => $webhookPayload['RecordingUrl'] ?? null,
        ]);
    }
}
