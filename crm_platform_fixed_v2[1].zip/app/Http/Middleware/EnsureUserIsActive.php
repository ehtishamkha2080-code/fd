<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Blocks every authenticated request from a deactivated user, not just the
 * ones behind role-gated routes. Without this, an admin toggling a user
 * inactive only stops *future* logins (see AuthenticatedSessionController) —
 * anyone with an already-open session keeps full access to Dashboard, Inbox,
 * CRM, and Reports (none of which are role-gated) until they happen to log
 * out. Applied to the whole 'auth' route group in routes/web.php.
 */
class EnsureUserIsActive
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user && ! $user->is_active) {
            auth()->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            abort(403, 'Your account has been deactivated. Contact an administrator.');
        }

        return $next($request);
    }
}
