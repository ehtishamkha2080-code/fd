<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class UserManagementController extends Controller
{
    public function index()
    {
        $users = User::with('roles')->latest()->paginate(20);
        $roles = Role::all();

        return view('admin.users.index', compact('users', 'roles'));
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'unique:users,email'],
            'password' => ['required', 'string', Password::min(8)->letters()->numbers()],
            'phone' => ['nullable', 'string', 'max:30'],
            'role' => ['required', 'exists:roles,name'],
        ]);

        $user = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'phone' => $data['phone'] ?? null,
        ]);

        $user->assignRole($data['role']);

        AuditLog::record('user_created', ['email' => $user->email], $user);

        return back()->with('status', 'User created successfully.');
    }

    public function updateRole(Request $request, User $user): RedirectResponse
    {
        $data = $request->validate([
            'role' => ['required', 'exists:roles,name'],
        ]);

        // Lockout guards: an admin demoting themself, or demoting the last active
        // admin, leaves the system with no one able to manage users.
        if ($user->id === auth()->id()) {
            return back()->with('status', 'You cannot change your own role.');
        }

        if ($user->hasRole('admin') && $data['role'] !== 'admin' && $this->activeAdminCount() <= 1) {
            return back()->with('status', 'Cannot demote the last active administrator.');
        }

        $role = Role::where('name', $data['role'])->firstOrFail();
        $user->roles()->sync([$role->id]);

        AuditLog::record('role_updated', ['role' => $data['role']], $user);

        return back()->with('status', 'Role updated.');
    }

    public function toggleActive(User $user): RedirectResponse
    {
        if ($user->id === auth()->id()) {
            return back()->with('status', 'You cannot deactivate your own account.');
        }

        if ($user->is_active && $user->hasRole('admin') && $this->activeAdminCount() <= 1) {
            return back()->with('status', 'Cannot deactivate the last active administrator.');
        }

        $user->update(['is_active' => ! $user->is_active]);

        AuditLog::record($user->is_active ? 'user_activated' : 'user_deactivated', null, $user);

        return back()->with('status', 'User status updated.');
    }

    protected function activeAdminCount(): int
    {
        return User::where('is_active', true)
            ->whereHas('roles', fn ($q) => $q->where('name', 'admin'))
            ->count();
    }
}
