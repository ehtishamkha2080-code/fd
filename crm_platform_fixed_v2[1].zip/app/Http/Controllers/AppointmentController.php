<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Contact;
use App\Models\User;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class AppointmentController extends Controller
{
    public function index(): View
    {
        $appointments = Appointment::with(['contact', 'agent'])
            ->orderBy('scheduled_at')
            ->paginate(25);

        $contacts = Contact::orderBy('name')->get(['id', 'name', 'phone']);
        $agents = User::where('is_active', true)
            ->whereHas('roles', fn ($q) => $q->whereIn('name', ['agent', 'manager']))
            ->get(['id', 'name']);

        return view('crm.appointments', compact('appointments', 'contacts', 'agents'));
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'contact_id' => ['required', 'exists:contacts,id'],
            'title' => ['required', 'string', 'max:255'],
            'scheduled_at' => ['required', 'date'],
            'duration_minutes' => ['nullable', 'integer', 'min:5'],
            'assigned_to' => ['nullable', 'exists:users,id'],
        ]);

        Appointment::create($data);

        return back()->with('status', 'Appointment scheduled.');
    }

    public function updateStatus(Request $request, Appointment $appointment): RedirectResponse
    {
        $data = $request->validate([
            'status' => ['required', 'in:scheduled,confirmed,completed,cancelled,no_show'],
        ]);

        $appointment->update($data);

        return back();
    }
}
