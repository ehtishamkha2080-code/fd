<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Contact extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name', 'phone', 'email', 'avatar_url', 'source', 'whatsapp_profile', 'last_contacted_at',
    ];

    protected function casts(): array
    {
        return [
            'whatsapp_profile' => 'array',
            'last_contacted_at' => 'datetime',
        ];
    }

    public function conversations()
    {
        return $this->hasMany(Conversation::class);
    }

    public function leads()
    {
        return $this->hasMany(Lead::class);
    }

    public function voiceCalls()
    {
        return $this->hasMany(VoiceCall::class)->latest();
    }

    /** Returns the most recent open conversation, or null — never creates one silently. */
    public function activeConversation(): ?Conversation
    {
        return $this->conversations()->where('status', 'open')->latest('last_message_at')->first();
    }

    /** Returns the most recent open conversation, creating one if none exists. */
    public function getOrCreateConversation(): Conversation
    {
        return $this->activeConversation()
            ?? $this->conversations()->create(['status' => 'open', 'unread' => true]);
    }
}
