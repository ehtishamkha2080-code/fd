<?php

namespace App\Jobs;

use App\Models\Conversation;
use App\Models\Message;
use App\Services\AI\AiAssistantService;
use App\Services\WhatsApp\WhatsAppCloudApiService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

/**
 * The Claude API call can take several seconds — far too slow to run inline in
 * the Meta webhook request (Meta times out and retries, causing duplicate
 * replies). This job moves the AI reply onto the queue worker instead.
 */
class SendAiAutoReply implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 2;

    public function __construct(
        public Conversation $conversation,
        public string $inboundBody,
    ) {}

    public function handle(AiAssistantService $ai, WhatsAppCloudApiService $whatsapp): void
    {
        // Re-check at execution time: an agent may have claimed the conversation
        // between webhook receipt and job execution — don't talk over them.
        $this->conversation->refresh();

        if ($this->conversation->assigned_to) {
            return;
        }

        $reply = $ai->generateChatbotReply($this->conversation, $this->inboundBody);

        if (trim($reply) === '') {
            return;
        }

        $result = $whatsapp->sendTextMessage($this->conversation->contact->phone, $reply);

        Message::create([
            'conversation_id' => $this->conversation->id,
            'user_id' => null,
            'direction' => 'outbound',
            'type' => 'text',
            'body' => $reply,
            'wa_message_id' => $result['messages'][0]['id'] ?? null,
            'status' => isset($result['messages']) ? 'sent' : 'failed',
            'raw_payload' => $result,
        ]);

        $this->conversation->update(['last_message_at' => now()]);
    }
}
